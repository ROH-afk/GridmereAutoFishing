# Gridmere Fishing Assistant (starter)

Ini adalah **kerangka proyek Android Studio**, bukan APK siap instal dan bukan bot otomatis.

## Fitur yang tersedia
- Aplikasi Android Kotlin.
- Permintaan izin overlay Android.
- Panel melayang dengan petunjuk kiri/kanan dan pemeriksaan progress secara manual.
- Tombol untuk menutup panel.

## Batasan versi awal
- Belum menangkap layar game.
- Belum mendeteksi ikan, zona hijau, atau progress bar secara otomatis.
- Tidak mengirim sentuhan otomatis ke game dan tidak memodifikasi server/game.
- Kompatibilitas dengan Gridmere belum diuji.

## Cara membuka
1. Ekstrak ZIP.
2. Buka folder `GridmereAutoFishing` melalui Android Studio.
3. Tunggu Gradle sync selesai.
4. Pilih perangkat Android 14 dan jalankan aplikasi.
5. Izinkan "tampil di atas aplikasi" untuk menguji panel overlay.

Untuk membuat APK: Android Studio > Build > Build APK(s).
