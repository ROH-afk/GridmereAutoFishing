package com.example.gridmereassistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.graphics.Color

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.argb(225, 12, 35, 58))
        }
        val heading = TextView(this).apply {
            text = "GRIDMERE ASSIST"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        val status = TextView(this).apply {
            text = "Pantau ikan dan zona hijau secara manual"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 8)
        }
        val left = Button(this).apply { text = "← Arah kiri (petunjuk)" }
        val right = Button(this).apply { text = "Arah kanan (petunjuk) →" }
        val full = Button(this).apply { text = "Progress penuh? Periksa" }
        val close = Button(this).apply {
            text = "Tutup panel"
            setOnClickListener { stopSelf() }
        }
        box.addView(heading); box.addView(status)
        box.addView(left); box.addView(right); box.addView(full); box.addView(close)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20; y = 140
        }
        wm.addView(box, params)
        panel = box
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
